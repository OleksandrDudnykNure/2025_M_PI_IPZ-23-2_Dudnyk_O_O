import React, { useRef } from "react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as yup from "yup";

function FormExample() {
    
    const initialValues = {
        name: "",
        email: "",
        phone: "",
        password: "",
        gender: "",
        hobbyReading: false,
        hobbyDrawing: false,
        hobbySport: false,
        birthday: "",
        time: "",
        number: 0,
        color: "#EDBB36",
        rating: 10,
        season: "summer",
        comment: "",
    };

    const validationSchema = yup.object().shape({
        name: yup
            .string()
            .matches(/^[A-Za-z]+$/, "Name must contain only English letters")
            .required("Name is required"),
        email: yup
            .string()
            .email("Invalid email format")
            .required("Email is required"),
        phone: yup
            .string()
            .matches(
                /^\+380\d{9}$/,
                "Phone number must start with '+380' and contain 12 digits"
            )
            .required("Phone number is required"),
        password: yup
            .string()
            .min(8, "Password must be at least 8 characters long")
            .matches(
                /[a-z]/,
                "Password must contain at least one lowercase letter"
            )
            .matches(
                /[A-Z]/,
                "Password must contain at least one uppercase letter"
            )
            .matches(/\d/, "Password must contain at least one number")
            .matches(
                /[@$!%*?&#]/,
                "Password must contain at least one special character"
            )
            .required("Password is required"),
        gender: yup.string().required("Gender is required"),
        birthday: yup
            .date()
            .required("Birthday is required")
            .test(
                "age",
                "You must be at least 13 years old and not older than 100 years (because it is impossible)",
                (value) => {
                    if (!value) return false;
                    const today = new Date();
                    const birthDate = new Date(value);
                    const age = today.getFullYear() - birthDate.getFullYear();
                    const monthDiff = today.getMonth() - birthDate.getMonth();
                    if (
                        monthDiff < 0 ||
                        (monthDiff === 0 &&
                            today.getDate() < birthDate.getDate())
                    ) {
                        return age - 1 >= 13 && age - 1 <= 100;
                    }
                    return age >= 13 && age <= 100;
                }
            ),
        time: yup.string().required("Time is required"),
        number: yup
            .number()
            .required("Number is required")
            .min(0, "Number must be at least 0")
            .max(100, "Number must be at most 100"),
    });

    const handleSubmit = (values, { setSubmitting }) => {
        alert("Form submitted successfully!");
        setSubmitting(false);
    };

    return (
        <div className="form-window">
            <div className="form-container">
                <div className="form-title">Example form</div>
                <Formik
                    initialValues={initialValues}
                    validationSchema={validationSchema}
                    onSubmit={handleSubmit}
                >
                    {({ isSubmitting }) => (
                        <Form>
                            {/* Name */}
                            <label className="form-label" htmlFor="name">
                                Name
                            </label>
                            <Field
                                className="form-field"
                                type="text"
                                id="name"
                                name="name"
                                placeholder="James"
                            />
                            <ErrorMessage
                                className="form-error-message"
                                name="name"
                                component="div"
                            />

                            {/* Email */}
                            <label className="form-label" htmlFor="email">
                                Email
                            </label>
                            <Field
                                className="form-field"
                                type="text"
                                id="email"
                                name="email"
                                placeholder="example@mail.com"
                            />
                            <ErrorMessage
                                className="form-error-message"
                                name="email"
                                component="div"
                            />

                            {/* Phone */}
                            <label className="form-label" htmlFor="phone">
                                Phone number
                            </label>
                            <Field
                                className="form-field"
                                type="text"
                                id="phone"
                                name="phone"
                                placeholder="+380yyxxxxxxx"
                            />
                            <ErrorMessage
                                className="form-error-message"
                                name="phone"
                                component="div"
                            />

                            {/* Password */}
                            <label className="form-label" htmlFor="password">
                                Password
                            </label>
                            <Field
                                className="form-field"
                                type="password"
                                id="password"
                                name="password"
                                placeholder="At least 8 characters"
                            />
                            <ErrorMessage
                                className="form-error-message"
                                name="password"
                                component="div"
                            />

                            {/* Gender */}
                            <div className="form-label">Gender</div>
                            <div className="form-selection-wrapper">
                                <Field
                                    className="form-radio"
                                    type="radio"
                                    id="male"
                                    name="gender"
                                    value="male"
                                />
                                <label
                                    className="form-selection-label"
                                    htmlFor="male"
                                >
                                    Male
                                </label>
                            </div>
                            <div className="form-selection-wrapper">
                                <Field
                                    className="form-radio"
                                    type="radio"
                                    id="female"
                                    name="gender"
                                    value="female"
                                />
                                <label
                                    className="form-selection-label"
                                    htmlFor="female"
                                >
                                    Female
                                </label>
                            </div>
                            <div className="form-selection-wrapper">
                                <Field
                                    className="form-radio"
                                    type="radio"
                                    id="other"
                                    name="gender"
                                    value="other"
                                />
                                <label
                                    className="form-selection-label"
                                    htmlFor="other"
                                >
                                    Other
                                </label>
                            </div>
                            <ErrorMessage
                                className="form-error-message"
                                name="gender"
                                component="div"
                            />

                            {/* Hobbies */}
                            <div className="form-label">
                                Choose your hobbies
                            </div>
                            <div className="form-selection-wrapper">
                                <Field
                                    className="form-checkbox"
                                    type="checkbox"
                                    id="hobbyReading"
                                    name="hobbyReading"
                                />
                                <label
                                    className="form-selection-label"
                                    htmlFor="hobbyReading"
                                >
                                    Reading
                                </label>
                            </div>
                            <div className="form-selection-wrapper">
                                <Field
                                    className="form-checkbox"
                                    type="checkbox"
                                    id="hobbyDrawing"
                                    name="hobbyDrawing"
                                />
                                <label
                                    className="form-selection-label"
                                    htmlFor="hobbyDrawing"
                                >
                                    Drawing
                                </label>
                            </div>
                            <div className="form-selection-wrapper">
                                <Field
                                    className="form-checkbox"
                                    type="checkbox"
                                    id="hobbySport"
                                    name="hobbySport"
                                />
                                <label
                                    className="form-selection-label"
                                    htmlFor="hobbySport"
                                >
                                    Sport
                                </label>
                            </div>

                            {/* Birthday */}
                            <label className="form-label" htmlFor="birthday">
                                Birthday
                            </label>
                            <Field
                                className="form-field"
                                type="date"
                                id="birthday"
                                name="birthday"
                            />
                            <ErrorMessage
                                className="form-error-message"
                                name="birthday"
                                component="div"
                            />

                            {/* Time */}
                            <label className="form-label" htmlFor="time">
                                When can we call you?
                            </label>
                            <Field
                                className="form-field"
                                type="time"
                                id="time"
                                name="time"
                            />
                            <ErrorMessage
                                className="form-error-message"
                                name="time"
                                component="div"
                            />

                            {/* Number */}
                            <label className="form-label" htmlFor="number">
                                Pick a number from 0 to 100
                            </label>
                            <Field
                                className="form-field"
                                type="number"
                                id="number"
                                name="number"
                                min="0"
                                max="100"
                            />
                            <ErrorMessage
                                className="form-error-message"
                                name="number"
                                component="div"
                            />

                            {/* Color */}
                            <label className="form-label" htmlFor="color">
                                Your favorite color
                            </label>
                            <Field
                                className="form-field"
                                type="color"
                                id="color"
                                name="color"
                            />

                            {/* Rating */}
                            <label className="form-label" htmlFor="rating">
                                Rate this form on a scale from 0 to 10
                            </label>
                            <Field
                                className="form-field"
                                type="range"
                                id="rating"
                                name="rating"
                                min="0"
                                max="10"
                            />

                            {/* Season */}
                            <label className="form-label" htmlFor="season">
                                Your favorite season
                            </label>
                            <Field
                                className="form-field"
                                as="select"
                                id="season"
                                name="season"
                            >
                                <option value="summer">Summer</option>
                                <option value="autumn">Autumn</option>
                                <option value="winter">Winter</option>
                                <option value="spring">Spring</option>
                            </Field>

                            {/* Comment */}
                            <label className="form-label" htmlFor="comment">
                                Comment
                            </label>
                            <Field
                                className="form-textarea"
                                as="textarea"
                                id="comment"
                                name="comment"
                                placeholder="Leave feedback about the form"
                            />

                            {/* Submit */}
                            <button
                                className="form-button"
                                type="submit"
                                disabled={isSubmitting}
                            >
                                Submit
                            </button>
                        </Form>
                    )}
                </Formik>
            </div>
        </div>
    );
}

export default FormExample;
