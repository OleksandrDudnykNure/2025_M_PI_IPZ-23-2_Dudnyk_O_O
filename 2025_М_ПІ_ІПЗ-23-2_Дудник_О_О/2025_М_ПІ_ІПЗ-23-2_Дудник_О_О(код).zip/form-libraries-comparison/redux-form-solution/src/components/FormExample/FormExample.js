import React from "react";
import { Field, reduxForm } from "redux-form";
import * as yup from "yup";

const validationSchema = yup.object().shape({
    name: yup
        .string()
        .matches(/^[A-Za-z]+$/, "Name must contain only English letters")
        .required("Name is required"),
    email: yup
        .string()
        .email("Invalid email format")
        .required("Email is required"),
    phone: yup
        .string()
        .matches(
            /^\+380\d{9}$/,
            "Phone number must start with '+380' and contain 12 digits"
        )
        .required("Phone number is required"),
    password: yup
        .string()
        .min(8, "Password must be at least 8 characters long")
        .matches(/[a-z]/, "Password must contain at least one lowercase letter")
        .matches(/[A-Z]/, "Password must contain at least one uppercase letter")
        .matches(/\d/, "Password must contain at least one number")
        .matches(
            /[@$!%*?&#]/,
            "Password must contain at least one special character"
        )
        .required("Password is required"),
    gender: yup.string().required("Gender is required"),
    birthday: yup
        .date()
        .required("Birthday is required")
        .test(
            "age",
            "You must be at least 13 years old and not older than 100 years",
            (value) => {
                if (!value) return false;
                const today = new Date();
                const birthDate = new Date(value);
                const age = today.getFullYear() - birthDate.getFullYear();
                const monthDiff = today.getMonth() - birthDate.getMonth();
                if (
                    monthDiff < 0 ||
                    (monthDiff === 0 && today.getDate() < birthDate.getDate())
                ) {
                    return age - 1 >= 13 && age - 1 <= 100;
                }
                return age >= 13 && age <= 100;
            }
        ),
    time: yup.string().required("Time is required"),
    number: yup
        .number()
        .required("Number is required")
        .min(0, "Number must be at least 0")
        .max(100, "Number must be at most 100"),
});

const validate = (values) => {
    const errors = {};
    try {
        validationSchema.validateSync(values, { abortEarly: false });
    } catch (err) {
        if (err.inner) {
            err.inner.forEach((validationError) => {
                errors[validationError.path] = validationError.message;
            });
        }
    }
    return errors;
};

const renderField = ({
    input,
    label,
    type,
    meta: { touched, error },
    placeholder,
    min,
    max,
}) => (
    <div>
        <label className="form-label">{label}</label>
        <input
            {...input}
            type={type}
            className="form-field"
            placeholder={placeholder}
            min={min}
            max={max}
        />
        {touched && error && (
            <span className="form-error-message">{error}</span>
        )}
    </div>
);

const renderRadioGroup = ({
    input,
    options,
    label,
    meta: { touched, error },
}) => (
    <div>
        <div className="form-label">{label}</div>
        {options.map((option) => (
            <div className="form-selection-wrapper" key={option.value}>
                <input
                    {...input}
                    type="radio"
                    value={option.value}
                    checked={input.value === option.value}
                    className="form-radio"
                />
                <label className="form-selection-label">{option.label}</label>
            </div>
        ))}
        {touched && error && (
            <span className="form-error-message">{error}</span>
        )}
    </div>
);

const renderCheckboxGroup = ({ input, options, label }) => (
    <div>
        <div className="form-label">{label}</div>
        {options.map((option) => (
            <div className="form-selection-wrapper" key={option.name}>
                <input
                    type="checkbox"
                    name={option.name}
                    checked={input.value.includes(option.name)}
                    onChange={(event) => {
                        const newValue = [...input.value];
                        if (event.target.checked) {
                            newValue.push(option.name);
                        } else {
                            newValue.splice(newValue.indexOf(option.name), 1);
                        }
                        input.onChange(newValue);
                    }}
                    className="form-checkbox"
                />
                <label className="form-selection-label">{option.label}</label>
            </div>
        ))}
    </div>
);

const renderSelect = ({ input, label, options, meta: { touched, error } }) => (
    <div>
        <label className="form-label">{label}</label>
        <select {...input} className="form-field">
            {options.map((option) => (
                <option key={option.value} value={option.value}>
                    {option.label}
                </option>
            ))}
        </select>
        {touched && error && (
            <span className="form-error-message">{error}</span>
        )}
    </div>
);

const renderTextarea = ({
    input,
    label,
    meta: { touched, error },
    placeholder,
}) => (
    <div>
        <label className="form-label">{label}</label>
        <textarea
            {...input}
            className="form-textarea"
            placeholder={placeholder}
        />
        {touched && error && (
            <span className="form-error-message">{error}</span>
        )}
    </div>
);

const FormExample = ({ handleSubmit, initialize, valid }) => {
    React.useEffect(() => {
        initialize({
            number: 0,
            color: "#EDBB36",
            rating: 10,
            season: "summer",
            hobbies: [],
        });
    }, [initialize]);

    const onSubmit = (values) => {
        if (!valid) {
            return;
        }
        alert("Form submitted successfully!");
        console.log(values);
    };

    return (
        <form className="form-window" onSubmit={handleSubmit(onSubmit)}>
            <div className="form-container">
                <div className="form-title">Example form</div>

                <Field
                    name="name"
                    type="text"
                    component={renderField}
                    label="Name"
                    placeholder="James"
                />
                <Field
                    name="email"
                    type="text"
                    component={renderField}
                    label="Email"
                    placeholder="example@mail.com"
                />
                <Field
                    name="phone"
                    type="text"
                    component={renderField}
                    label="Phone number"
                    placeholder="+380yyxxxxxxx"
                />
                <Field
                    name="password"
                    type="password"
                    component={renderField}
                    label="Password"
                    placeholder="At least 8 characters"
                />

                <Field
                    name="gender"
                    component={renderRadioGroup}
                    label="Gender"
                    options={[
                        { value: "male", label: "Male" },
                        { value: "female", label: "Female" },
                        { value: "other", label: "Other" },
                    ]}
                />

                <Field
                    name="hobbies"
                    component={renderCheckboxGroup}
                    label="Choose your hobbies"
                    options={[
                        { name: "hobbyReading", label: "Reading" },
                        { name: "hobbyDrawing", label: "Drawing" },
                        { name: "hobbySport", label: "Sport" },
                    ]}
                />

                <Field
                    name="birthday"
                    type="date"
                    component={renderField}
                    label="Birthday"
                />
                <Field
                    name="time"
                    type="time"
                    component={renderField}
                    label="When can we call you?"
                />
                <Field
                    name="number"
                    type="number"
                    component={renderField}
                    label="Pick a number from 0 to 100"
                    min={0}
                    max={100}
                />
                <Field
                    name="color"
                    type="color"
                    component={renderField}
                    label="Your favorite color"
                />
                <Field
                    name="rating"
                    type="range"
                    component={renderField}
                    label="Rate this form on a scale from 0 to 10"
                    min={0}
                    max={10}
                />

                <Field
                    name="season"
                    component={renderSelect}
                    label="Your favorite season"
                    options={[
                        { value: "summer", label: "Summer" },
                        { value: "autumn", label: "Autumn" },
                        { value: "winter", label: "Winter" },
                        { value: "spring", label: "Spring" },
                    ]}
                />

                <Field
                    name="comment"
                    component={renderTextarea}
                    label="Comment"
                    placeholder="Leave feedback about the form"
                />

                <button className="form-button" type="submit">
                    Submit
                </button>
            </div>
        </form>
    );
};

export default reduxForm({
    form: "exampleForm",
    validate,
    destroyOnUnmount: false,
    enableReinitialize: false,
})(FormExample);
