import React, { useRef } from "react";
import { Form, Field } from "react-final-form";
import * as yup from "yup";

function FormExample() {
    
    const validationSchema = yup.object().shape({
        name: yup
            .string()
            .matches(/^[A-Za-z]+$/, "Name must contain only English letters")
            .required("Name is required"),
        email: yup
            .string()
            .email("Invalid email format")
            .required("Email is required"),
        phone: yup
            .string()
            .matches(
                /^\+380\d{9}$/,
                "Phone number must start with '+380' and contain 12 digits"
            )
            .required("Phone number is required"),
        password: yup
            .string()
            .min(8, "Password must be at least 8 characters long")
            .matches(
                /[a-z]/,
                "Password must contain at least one lowercase letter"
            )
            .matches(
                /[A-Z]/,
                "Password must contain at least one uppercase letter"
            )
            .matches(/\d/, "Password must contain at least one number")
            .matches(
                /[@$!%*?&#]/,
                "Password must contain at least one special character"
            )
            .required("Password is required"),
        gender: yup.string().required("Gender is required"),
        birthday: yup
            .date()
            .required("Birthday is required")
            .test(
                "age",
                "You must be at least 13 years old and not older than 100 years (because it is impossible)",
                (value) => {
                    if (!value) return false;
                    const today = new Date();
                    const birthDate = new Date(value);
                    const age = today.getFullYear() - birthDate.getFullYear();
                    const monthDiff = today.getMonth() - birthDate.getMonth();
                    if (
                        monthDiff < 0 ||
                        (monthDiff === 0 &&
                            today.getDate() < birthDate.getDate())
                    ) {
                        return age - 1 >= 13 && age - 1 <= 100;
                    }
                    return age >= 13 && age <= 100;
                }
            ),
        time: yup.string().required("Time is required"),
        number: yup
            .number()
            .required("Number is required")
            .min(0, "Number must be at least 0")
            .max(100, "Number must be at most 100"),
    });

    const validate = async (values) => {
        try {
            await validationSchema.validate(values, { abortEarly: false });
        } catch (err) {
            if (err instanceof yup.ValidationError) {
                return err.inner.reduce((errors, error) => {
                    errors[error.path] = error.message;
                    return errors;
                }, {});
            }
        }
    };

    const onSubmit = async (values, form) => {
        alert("Form submitted successfully!");
        form.reset();
    };

    return (
        <div className="form-window">
            <div className="form-container">
                <div className="form-title">Example form</div>
                <Form
                    onSubmit={onSubmit}
                    validate={validate}
                    initialValues={{
                        name: "",
                        email: "",
                        phone: "",
                        password: "",
                        gender: "",
                        hobbyReading: false,
                        hobbyDrawing: false,
                        hobbySport: false,
                        birthday: null,
                        time: null,
                        number: 0,
                        color: "#EDBB36",
                        rating: 10,
                        season: "summer",
                        comment: "",
                    }}
                    render={({ handleSubmit, submitError }) => (
                        <form onSubmit={handleSubmit}>
                            {submitError && (
                                <div className="form-error-message">
                                    {submitError}
                                </div>
                            )}
                            {/* Name */}
                            <Field name="name">
                                {({ input, meta }) => (
                                    <>
                                        <label
                                            className="form-label"
                                            htmlFor="name"
                                        >
                                            Name
                                        </label>
                                        <input
                                            {...input}
                                            className="form-field"
                                            id="name"
                                            placeholder="James"
                                        />
                                        {meta.touched && meta.error && (
                                            <span className="form-error-message">
                                                {meta.error}
                                            </span>
                                        )}
                                    </>
                                )}
                            </Field>
                            {/* Email */}
                            <Field name="email">
                                {({ input, meta }) => (
                                    <>
                                        <label
                                            className="form-label"
                                            htmlFor="email"
                                        >
                                            Email
                                        </label>
                                        <input
                                            {...input}
                                            className="form-field"
                                            id="email"
                                            placeholder="example@mail.com"
                                        />
                                        {meta.touched && meta.error && (
                                            <span className="form-error-message">
                                                {meta.error}
                                            </span>
                                        )}
                                    </>
                                )}
                            </Field>
                            {/* Phone */}
                            <Field name="phone">
                                {({ input, meta }) => (
                                    <>
                                        <label
                                            className="form-label"
                                            htmlFor="phone"
                                        >
                                            Phone number
                                        </label>
                                        <input
                                            {...input}
                                            className="form-field"
                                            id="phone"
                                            placeholder="+380yyxxxxxxx"
                                        />
                                        {meta.touched && meta.error && (
                                            <span className="form-error-message">
                                                {meta.error}
                                            </span>
                                        )}
                                    </>
                                )}
                            </Field>
                            {/* Password */}
                            <Field name="password">
                                {({ input, meta }) => (
                                    <>
                                        <label
                                            className="form-label"
                                            htmlFor="password"
                                        >
                                            Password
                                        </label>
                                        <input
                                            {...input}
                                            className="form-field"
                                            id="password"
                                            type="password"
                                            placeholder="At least 8 characters"
                                        />
                                        {meta.touched && meta.error && (
                                            <span className="form-error-message">
                                                {meta.error}
                                            </span>
                                        )}
                                    </>
                                )}
                            </Field>
                            {/* Gender */}
                            <div className="form-label">Gender</div>
                            <Field name="gender" type="radio" value="male">
                                {({ input }) => (
                                    <div className="form-selection-wrapper">
                                        <input
                                            {...input}
                                            className="form-radio"
                                            id="male"
                                        />
                                        <label
                                            className="form-selection-label"
                                            htmlFor="male"
                                        >
                                            Male
                                        </label>
                                    </div>
                                )}
                            </Field>
                            <Field name="gender" type="radio" value="female">
                                {({ input }) => (
                                    <div className="form-selection-wrapper">
                                        <input
                                            {...input}
                                            className="form-radio"
                                            id="female"
                                        />
                                        <label
                                            className="form-selection-label"
                                            htmlFor="female"
                                        >
                                            Female
                                        </label>
                                    </div>
                                )}
                            </Field>
                            <Field name="gender" type="radio" value="other">
                                {({ input }) => (
                                    <div className="form-selection-wrapper">
                                        <input
                                            {...input}
                                            className="form-radio"
                                            id="other"
                                        />
                                        <label
                                            className="form-selection-label"
                                            htmlFor="other"
                                        >
                                            Other
                                        </label>
                                    </div>
                                )}
                            </Field>
                            {/* Gender error display */}
                            <Field name="gender">
                                {({ meta }) =>
                                    meta.touched && meta.error ? (
                                        <span className="form-error-message">
                                            {meta.error}
                                        </span>
                                    ) : null
                                }
                            </Field>
                            {/* Hobbies */}
                            <div className="form-label">
                                Choose your hobbies
                            </div>
                            <Field name="hobbyReading" type="checkbox">
                                {({ input }) => (
                                    <div className="form-selection-wrapper">
                                        <input
                                            {...input}
                                            className="form-checkbox"
                                            id="hobbyReading"
                                        />
                                        <label
                                            className="form-selection-label"
                                            htmlFor="hobbyReading"
                                        >
                                            Reading
                                        </label>
                                    </div>
                                )}
                            </Field>
                            <Field name="hobbyDrawing" type="checkbox">
                                {({ input }) => (
                                    <div className="form-selection-wrapper">
                                        <input
                                            {...input}
                                            className="form-checkbox"
                                            id="hobbyDrawing"
                                        />
                                        <label
                                            className="form-selection-label"
                                            htmlFor="hobbyDrawing"
                                        >
                                            Drawing
                                        </label>
                                    </div>
                                )}
                            </Field>
                            <Field name="hobbySport" type="checkbox">
                                {({ input }) => (
                                    <div className="form-selection-wrapper">
                                        <input
                                            {...input}
                                            className="form-checkbox"
                                            id="hobbySport"
                                        />
                                        <label
                                            className="form-selection-label"
                                            htmlFor="hobbySport"
                                        >
                                            Sport
                                        </label>
                                    </div>
                                )}
                            </Field>
                            {/* Birthday */}
                            <Field name="birthday">
                                {({ input, meta }) => (
                                    <>
                                        <label
                                            className="form-label"
                                            htmlFor="birthday"
                                        >
                                            Birthday
                                        </label>
                                        <input
                                            {...input}
                                            className="form-field"
                                            id="birthday"
                                            type="date"
                                        />
                                        {meta.touched && meta.error && (
                                            <span className="form-error-message">
                                                {meta.error}
                                            </span>
                                        )}
                                    </>
                                )}
                            </Field>
                            {/* Time */}
                            <Field name="time">
                                {({ input, meta }) => (
                                    <>
                                        <label
                                            className="form-label"
                                            htmlFor="time"
                                        >
                                            When can we call you?
                                        </label>
                                        <input
                                            {...input}
                                            className="form-field"
                                            id="time"
                                            type="time"
                                        />
                                        {meta.touched && meta.error && (
                                            <span className="form-error-message">
                                                {meta.error}
                                            </span>
                                        )}
                                    </>
                                )}
                            </Field>
                            {/* Number */}
                            <Field name="number">
                                {({ input, meta }) => (
                                    <>
                                        <label
                                            className="form-label"
                                            htmlFor="number"
                                        >
                                            Pick a number from 0 to 100
                                        </label>
                                        <input
                                            {...input}
                                            className="form-field"
                                            id="number"
                                            type="number"
                                            min="0"
                                            max="100"
                                        />
                                        {meta.touched && meta.error && (
                                            <span className="form-error-message">
                                                {meta.error}
                                            </span>
                                        )}
                                    </>
                                )}
                            </Field>
                            {/* Color */}
                            <Field name="color">
                                {({ input }) => (
                                    <>
                                        <label
                                            className="form-label"
                                            htmlFor="color"
                                        >
                                            Your favorite color
                                        </label>
                                        <input
                                            {...input}
                                            className="form-field"
                                            id="color"
                                            type="color"
                                        />
                                    </>
                                )}
                            </Field>
                            {/* Rating */}
                            <Field name="rating">
                                {({ input }) => (
                                    <>
                                        <label
                                            className="form-label"
                                            htmlFor="rating"
                                        >
                                            Rate this form on a scale from 0 to
                                            10
                                        </label>
                                        <input
                                            {...input}
                                            className="form-field"
                                            id="rating"
                                            type="range"
                                            min="0"
                                            max="10"
                                        />
                                    </>
                                )}
                            </Field>
                            {/* Season */}
                            <Field name="season">
                                {({ input }) => (
                                    <>
                                        <label
                                            className="form-label"
                                            htmlFor="season"
                                        >
                                            Your favorite season
                                        </label>
                                        <select
                                            {...input}
                                            className="form-field"
                                            id="season"
                                        >
                                            <option value="summer">
                                                Summer
                                            </option>
                                            <option value="autumn">
                                                Autumn
                                            </option>
                                            <option value="winter">
                                                Winter
                                            </option>
                                            <option value="spring">
                                                Spring
                                            </option>
                                        </select>
                                    </>
                                )}
                            </Field>
                            {/* Comment */}
                            <Field name="comment">
                                {({ input }) => (
                                    <>
                                        <label
                                            className="form-label"
                                            htmlFor="comment"
                                        >
                                            Comment
                                        </label>
                                        <textarea
                                            {...input}
                                            className="form-textarea"
                                            id="comment"
                                            placeholder="Leave feedback about the form"
                                        />
                                    </>
                                )}
                            </Field>
                            <button className="form-button" type="submit">
                                Submit
                            </button>
                        </form>
                    )}
                />
            </div>
        </div>
    );
}

export default FormExample;
