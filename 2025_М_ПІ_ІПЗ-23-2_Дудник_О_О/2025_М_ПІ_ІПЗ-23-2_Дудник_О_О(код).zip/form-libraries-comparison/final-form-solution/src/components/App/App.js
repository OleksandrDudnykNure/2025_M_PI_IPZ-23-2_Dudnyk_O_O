import "../../styles/main.css";
import FormExample from "../FormExample";

function App() {
  return (
    <FormExample />
  );
}

export default App;