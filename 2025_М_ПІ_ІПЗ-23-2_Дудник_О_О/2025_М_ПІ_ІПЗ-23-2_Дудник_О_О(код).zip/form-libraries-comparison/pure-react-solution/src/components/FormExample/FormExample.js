import React, { useState, useRef } from "react";
import * as yup from "yup";

function FormExample() {
    const [formData, setFormData] = useState({
        name: "",
        email: "",
        phone: "",
        password: "",
        gender: "",
        hobbyReading: false,
        hobbyDrawing: false,
        hobbySport: false,
        birthday: "",
        time: "",
        number: 0,
        color: "#EDBB36",
        rating: 10,
        season: "summer",
        comment: "",
    });

    const [fieldErrors, setFieldErrors] = useState({});

    const validateField = async (name, value) => {
        try {
            await yup.reach(validationSchema, name).validate(value);
            setFieldErrors((prev) => ({
                ...prev,
                [name]: undefined,
            }));
        } catch (err) {
            setFieldErrors((prev) => ({
                ...prev,
                [name]: err.message,
            }));
        }
    };

    const handleChange = (event) => {
        const { name, value } = event.target;
        setFormData((prev) => ({
            ...prev,
            [name]: value,
        }));
        validateField(name, value);
    };

    const handleCheckboxChange = (event) => {
        const { name, checked } = event.target;
        setFormData((prev) => ({
            ...prev,
            [name]: checked,
        }));
    };

    const validationSchema = yup.object().shape({
        name: yup
            .string()
            .matches(/^[A-Za-z]+$/, "Name must contain only English letters")
            .required("Name is required"),
        email: yup
            .string()
            .email("Invalid email format")
            .required("Email is required"),
        phone: yup
            .string()
            .matches(
                /^\+380\d{9}$/,
                "Phone number must start with '+380' and contain 12 digits"
            )
            .required("Phone number is required"),
        password: yup
            .string()
            .min(8, "Password must be at least 8 characters long")
            .matches(
                /[a-z]/,
                "Password must contain at least one lowercase letter"
            )
            .matches(
                /[A-Z]/,
                "Password must contain at least one uppercase letter"
            )
            .matches(/\d/, "Password must contain at least one number")
            .matches(
                /[@$!%*?&#]/,
                "Password must contain at least one special character"
            )
            .required("Password is required"),
        gender: yup.string().required("Gender is required"),
        birthday: yup
            .date()
            .required("Birthday is required")
            .test(
                "age",
                "You must be at least 13 years old and not older than 100 years (because it is impossible)",
                (value) => {
                    if (!value) return false;
                    const today = new Date();
                    const birthDate = new Date(value);
                    const age = today.getFullYear() - birthDate.getFullYear();
                    const monthDiff = today.getMonth() - birthDate.getMonth();
                    if (
                        monthDiff < 0 ||
                        (monthDiff === 0 &&
                            today.getDate() < birthDate.getDate())
                    ) {
                        return age - 1 >= 13 && age - 1 <= 100;
                    }
                    return age >= 13 && age <= 100;
                }
            ),
        time: yup.string().required("Time is required"),
        number: yup
            .number()
            .required("Number is required")
            .min(0, "Number must be at least 0")
            .max(100, "Number must be at most 100"),
    });

    const handleSubmit = async () => {
        try {
            await validationSchema.validate(formData, { abortEarly: false });
            alert("Form submitted successfully!");
            setFieldErrors({});
        } catch (err) {
            if (err instanceof yup.ValidationError) {
                const errors = {};
                err.inner.forEach((error) => {
                    errors[error.path] = error.message;
                });
                setFieldErrors(errors);
            }
        }
    };

    return (
        <div className="form-window">
            <div className="form-container">
                <div className="form-title">Example form</div>

                {/* Name */}
                <label className="form-label" htmlFor="name">
                    Name
                </label>
                <input
                    className="form-field"
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="James"
                />
                {fieldErrors.name && (
                    <div className="form-error-message">{fieldErrors.name}</div>
                )}

                {/* Email */}
                <label className="form-label" htmlFor="email">
                    Email
                </label>
                <input
                    className="form-field"
                    type="text"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="example@mail.com"
                />
                {fieldErrors.email && (
                    <div className="form-error-message">
                        {fieldErrors.email}
                    </div>
                )}

                {/* Phone */}
                <label className="form-label" htmlFor="phone">
                    Phone number
                </label>
                <input
                    className="form-field"
                    type="text"
                    id="phone"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="+380yyxxxxxxx"
                />
                {fieldErrors.phone && (
                    <div className="form-error-message">
                        {fieldErrors.phone}
                    </div>
                )}

                {/* Password */}
                <label className="form-label" htmlFor="password">
                    Password
                </label>
                <input
                    className="form-field"
                    type="password"
                    id="password"
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    placeholder="At least 8 characters"
                />
                {fieldErrors.password && (
                    <div className="form-error-message">
                        {fieldErrors.password}
                    </div>
                )}

                {/* Gender */}
                <div className="form-label">Gender</div>

                <div className="form-selection-wrapper">
                    <input
                        className="form-radio"
                        type="radio"
                        id="male"
                        name="gender"
                        value="male"
                        checked={formData.gender === "male"}
                        onChange={handleChange}
                    />
                    <label className="form-selection-label" htmlFor="male">
                        Male
                    </label>
                </div>

                <div className="form-selection-wrapper">
                    <input
                        className="form-radio"
                        type="radio"
                        id="female"
                        name="gender"
                        value="female"
                        checked={formData.gender === "female"}
                        onChange={handleChange}
                    />
                    <label className="form-selection-label" htmlFor="female">
                        Female
                    </label>
                </div>

                <div className="form-selection-wrapper">
                    <input
                        className="form-radio"
                        type="radio"
                        id="other"
                        name="gender"
                        value="other"
                        checked={formData.gender === "other"}
                        onChange={handleChange}
                    />
                    <label className="form-selection-label" htmlFor="other">
                        Other
                    </label>
                </div>
                {fieldErrors.gender && (
                    <div className="form-error-message">
                        {fieldErrors.gender}
                    </div>
                )}

                {/* Hobbies */}
                <div className="form-label">Choose your hobbies</div>

                <div className="form-selection-wrapper">
                    <input
                        className="form-checkbox"
                        type="checkbox"
                        id="hobbyReading"
                        name="hobbyReading"
                        checked={formData.hobbyReading}
                        onChange={handleCheckboxChange}
                    />
                    <label
                        className="form-selection-label"
                        htmlFor="hobbyReading"
                    >
                        Reading
                    </label>
                </div>

                <div className="form-selection-wrapper">
                    <input
                        className="form-checkbox"
                        type="checkbox"
                        id="hobbyDrawing"
                        name="hobbyDrawing"
                        checked={formData.hobbyDrawing}
                        onChange={handleCheckboxChange}
                    />
                    <label
                        className="form-selection-label"
                        htmlFor="hobbyDrawing"
                    >
                        Drawing
                    </label>
                </div>

                <div className="form-selection-wrapper">
                    <input
                        className="form-checkbox"
                        type="checkbox"
                        id="hobbySport"
                        name="hobbySport"
                        checked={formData.hobbySport}
                        onChange={handleCheckboxChange}
                    />
                    <label
                        className="form-selection-label"
                        htmlFor="hobbySport"
                    >
                        Sport
                    </label>
                </div>

                {/* Birthday */}
                <label className="form-label" htmlFor="birthday">
                    Birthday
                </label>
                <input
                    className="form-field"
                    type="date"
                    id="birthday"
                    name="birthday"
                    value={formData.birthday}
                    onChange={handleChange}
                />
                {fieldErrors.birthday && (
                    <div className="form-error-message">
                        {fieldErrors.birthday}
                    </div>
                )}

                {/* Time */}
                <label className="form-label" htmlFor="time">
                    When can we call you?
                </label>
                <input
                    className="form-field"
                    type="time"
                    id="time"
                    name="time"
                    value={formData.time}
                    onChange={handleChange}
                />
                {fieldErrors.time && (
                    <div className="form-error-message">{fieldErrors.time}</div>
                )}

                {/* Number */}
                <label className="form-label" htmlFor="number">
                    Pick a number from 0 to 100
                </label>
                <input
                    className="form-field"
                    type="number"
                    id="number"
                    name="number"
                    value={formData.number}
                    onChange={handleChange}
                    min="0"
                    max="100"
                />
                {fieldErrors.number && (
                    <div className="form-error-message">
                        {fieldErrors.number}
                    </div>
                )}

                {/* Color */}
                <label className="form-label" htmlFor="color">
                    Your favorite color
                </label>
                <input
                    className="form-field"
                    type="color"
                    id="color"
                    name="color"
                    value={formData.color}
                    onChange={handleChange}
                />

                {/* Rating */}
                <label className="form-label" htmlFor="rating">
                    Rate this form on a scale from 0 to 10
                </label>
                <input
                    className="form-field"
                    type="range"
                    id="rating"
                    name="rating"
                    value={formData.rating}
                    onChange={handleChange}
                    min="0"
                    max="10"
                />

                {/* Season */}
                <label className="form-label" htmlFor="season">
                    Your favorite season
                </label>
                <select
                    className="form-field"
                    id="season"
                    name="season"
                    value={formData.season}
                    onChange={handleChange}
                >
                    <option value="summer">Summer</option>
                    <option value="autumn">Autumn</option>
                    <option value="winter">Winter</option>
                    <option value="spring">Spring</option>
                </select>

                {/* Comment */}
                <label className="form-label" htmlFor="comment">
                    Comment
                </label>
                <textarea
                    className="form-textarea"
                    id="comment"
                    name="comment"
                    value={formData.comment}
                    onChange={handleChange}
                    placeholder="Leave feedback about the form"
                />

                {/* Submit */}
                <button className="form-button" onClick={handleSubmit}>
                    Submit
                </button>
            </div>
        </div>
    );
}

export default FormExample;
