import React, { useRef } from "react";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

function FormExample() {
    
    const validationSchema = yup.object().shape({
        name: yup
            .string()
            .matches(/^[A-Za-z]+$/, "Name must contain only English letters")
            .required("Name is required"),
        email: yup
            .string()
            .email("Invalid email format")
            .required("Email is required"),
        phone: yup
            .string()
            .matches(
                /^\+380\d{9}$/,
                "Phone number must start with '+380' and contain 12 digits"
            )
            .required("Phone number is required"),
        password: yup
            .string()
            .min(8, "Password must be at least 8 characters long")
            .matches(
                /[a-z]/,
                "Password must contain at least one lowercase letter"
            )
            .matches(
                /[A-Z]/,
                "Password must contain at least one uppercase letter"
            )
            .matches(/\d/, "Password must contain at least one number")
            .matches(
                /[@$!%*?&#]/,
                "Password must contain at least one special character"
            )
            .required("Password is required"),
        gender: yup.string().required("Gender is required"),
        birthday: yup
            .date()
            .required("Birthday is required")
            .test(
                "age",
                "You must be at least 13 years old and not older than 100 years (because it is impossible)",
                (value) => {
                    if (!value) return false;
                    const today = new Date();
                    const birthDate = new Date(value);
                    const age = today.getFullYear() - birthDate.getFullYear();
                    const monthDiff = today.getMonth() - birthDate.getMonth();
                    if (
                        monthDiff < 0 ||
                        (monthDiff === 0 &&
                            today.getDate() < birthDate.getDate())
                    ) {
                        return age - 1 >= 13 && age - 1 <= 100;
                    }
                    return age >= 13 && age <= 100;
                }
            ),
        time: yup.string().required("Time is required"),
        number: yup
            .number()
            .required("Number is required")
            .min(0, "Number must be at least 0")
            .max(100, "Number must be at most 100"),
    });

    const {
        register,
        handleSubmit,
        control,
        formState: { errors },
    } = useForm({
        resolver: yupResolver(validationSchema),
        defaultValues: {
            name: "",
            email: "",
            phone: "",
            password: "",
            gender: "",
            hobbyReading: false,
            hobbyDrawing: false,
            hobbySport: false,
            birthday: null,
            time: null,
            number: 0,
            color: "#EDBB36",
            rating: 10,
            season: "summer",
            comment: "",
        },
    });

    const onSubmit = (data) => {
        alert("Form submitted successfully!");
        console.log(data);
    };

    return (
        <div className="form-window">
            <div className="form-container">
                <div className="form-title">Example form</div>

                <form onSubmit={handleSubmit(onSubmit)}>
                    {/* Name */}
                    <label className="form-label" htmlFor="name">
                        Name
                    </label>
                    <input
                        className="form-field"
                        type="text"
                        id="name"
                        {...register("name")}
                        placeholder="James"
                    />
                    {errors.name && (
                        <div className="form-error-message">
                            {errors.name.message}
                        </div>
                    )}

                    {/* Email */}
                    <label className="form-label" htmlFor="email">
                        Email
                    </label>
                    <input
                        className="form-field"
                        type="text"
                        id="email"
                        {...register("email")}
                        placeholder="example@mail.com"
                    />
                    {errors.email && (
                        <div className="form-error-message">
                            {errors.email.message}
                        </div>
                    )}

                    {/* Phone */}
                    <label className="form-label" htmlFor="phone">
                        Phone number
                    </label>
                    <input
                        className="form-field"
                        type="text"
                        id="phone"
                        {...register("phone")}
                        placeholder="+380yyxxxxxxx"
                    />
                    {errors.phone && (
                        <div className="form-error-message">
                            {errors.phone.message}
                        </div>
                    )}

                    {/* Password */}
                    <label className="form-label" htmlFor="password">
                        Password
                    </label>
                    <input
                        className="form-field"
                        type="password"
                        id="password"
                        {...register("password")}
                        placeholder="At least 8 characters"
                    />
                    {errors.password && (
                        <div className="form-error-message">
                            {errors.password.message}
                        </div>
                    )}

                    {/* Gender */}
                    <div className="form-label">Gender</div>
                    <div className="form-selection-wrapper">
                        <input
                            className="form-radio"
                            type="radio"
                            id="male"
                            value="male"
                            {...register("gender")}
                        />
                        <label className="form-selection-label" htmlFor="male">
                            Male
                        </label>
                    </div>
                    <div className="form-selection-wrapper">
                        <input
                            className="form-radio"
                            type="radio"
                            id="female"
                            value="female"
                            {...register("gender")}
                        />
                        <label
                            className="form-selection-label"
                            htmlFor="female"
                        >
                            Female
                        </label>
                    </div>
                    <div className="form-selection-wrapper">
                        <input
                            className="form-radio"
                            type="radio"
                            id="other"
                            value="other"
                            {...register("gender")}
                        />
                        <label className="form-selection-label" htmlFor="other">
                            Other
                        </label>
                    </div>
                    {errors.gender && (
                        <div className="form-error-message">
                            {errors.gender.message}
                        </div>
                    )}

                    {/* Hobbies */}
                    <div className="form-label">Choose your hobbies</div>
                    <div className="form-selection-wrapper">
                        <input
                            className="form-checkbox"
                            type="checkbox"
                            id="hobbyReading"
                            {...register("hobbyReading")}
                        />
                        <label
                            className="form-selection-label"
                            htmlFor="hobbyReading"
                        >
                            Reading
                        </label>
                    </div>
                    <div className="form-selection-wrapper">
                        <input
                            className="form-checkbox"
                            type="checkbox"
                            id="hobbyDrawing"
                            {...register("hobbyDrawing")}
                        />
                        <label
                            className="form-selection-label"
                            htmlFor="hobbyDrawing"
                        >
                            Drawing
                        </label>
                    </div>
                    <div className="form-selection-wrapper">
                        <input
                            className="form-checkbox"
                            type="checkbox"
                            id="hobbySport"
                            {...register("hobbySport")}
                        />
                        <label
                            className="form-selection-label"
                            htmlFor="hobbySport"
                        >
                            Sport
                        </label>
                    </div>

                    {/* Birthday */}
                    <label className="form-label" htmlFor="birthday">
                        Birthday
                    </label>
                    <input
                        className="form-field"
                        type="date"
                        id="birthday"
                        {...register("birthday")}
                    />
                    {errors.birthday && (
                        <div className="form-error-message">
                            {errors.birthday.message}
                        </div>
                    )}

                    {/* Time */}
                    <label className="form-label" htmlFor="time">
                        When can we call you?
                    </label>
                    <input
                        className="form-field"
                        type="time"
                        id="time"
                        {...register("time")}
                    />
                    {errors.time && (
                        <div className="form-error-message">
                            {errors.time.message}
                        </div>
                    )}

                    {/* Number */}
                    <label className="form-label" htmlFor="number">
                        Pick a number from 0 to 100
                    </label>
                    <input
                        className="form-field"
                        type="number"
                        id="number"
                        {...register("number")}
                        min="0"
                        max="100"
                    />
                    {errors.number && (
                        <div className="form-error-message">
                            {errors.number.message}
                        </div>
                    )}

                    {/* Color */}
                    <label className="form-label" htmlFor="color">
                        Your favorite color
                    </label>
                    <Controller
                        name="color"
                        control={control}
                        render={({ field }) => (
                            <input
                                className="form-field"
                                type="color"
                                id="color"
                                {...field}
                            />
                        )}
                    />

                    {/* Rating */}
                    <label className="form-label" htmlFor="rating">
                        Rate this form on a scale from 0 to 10
                    </label>
                    <input
                        className="form-field"
                        type="range"
                        id="rating"
                        {...register("rating")}
                        min="0"
                        max="10"
                    />

                    {/* Season */}
                    <label className="form-label" htmlFor="season">
                        Your favorite season
                    </label>
                    <select
                        className="form-field"
                        id="season"
                        {...register("season")}
                    >
                        <option value="summer">Summer</option>
                        <option value="autumn">Autumn</option>
                        <option value="winter">Winter</option>
                        <option value="spring">Spring</option>
                    </select>

                    {/* Comment */}
                    <label className="form-label" htmlFor="comment">
                        Comment
                    </label>
                    <textarea
                        className="form-textarea"
                        id="comment"
                        {...register("comment")}
                        placeholder="Leave feedback about the form"
                    />

                    {/* Submit */}
                    <button className="form-button" type="submit">
                        Submit
                    </button>
                </form>
            </div>
        </div>
    );
}

export default FormExample;
